<?php
    $zip = new ZipArchive();
     $zip_name = "File".time().".zip";           // Zip name
            $zip->open($zip_name, ZIPARCHIVE::CREATE);
            $zip->setPassword($_POST["password"]);       

            for ($a = 0; $a < count($_FILES["files"]["name"]); $a++)  
               {
                        $content = file_get_contents($_FILES["files"]["tmp_name"][$a]);
                        $zip->addFromString($_FILES["files"]["name"][$a], $content);
                        $zip->setEncryptionName($_FILES["files"]["name"][$a], ZipArchive::EM_AES_256);
                }
                $zip->close(); 
                if(file_exists($zip_name))  
                {  
                     // push to download the zip  
                     header('Content-type: application/zip');  
                     header('Content-Disposition: attachment; filename="'.$zip_name.'"');  
                     readfile($zip_name);  
                     // remove zip file is exists in temp path  
                     unlink($zip_name);  
                }  
?>
