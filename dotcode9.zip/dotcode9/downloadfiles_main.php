<?php session_start();
if(isset($_SESSION['uname']))
{
?>
<?php include "header2.php"; ?>
<?php  
 $error = ""; //error holder  
 if(isset($_POST['createpdf']))  
 {  
      $post = $_POST;   
      $file_folder = "uploadfiles/"; // folder to load files  
      if(extension_loaded('zip'))  
      {   
           // Checking ZIP extension is available  
           if(isset($post['files']) and count($post['files']) > 0)  
           {   
                // Checking files are selected  
                $zip = new ZipArchive(); // Load zip library   
                $zip_name = "Download" .time().".zip";           // Zip name  
                if($zip->open($zip_name, ZIPARCHIVE::CREATE)!==TRUE)  
                {   
                     // Opening zip file to load files  
                     $error .= "* Sorry ZIP creation failed at this time";  
                }  
                foreach($post['files'] as $file)  
                {   
                     $zip->addFile($file_folder.$file); // Adding files into zip  
                }  
                $zip->close();  
                if(file_exists($zip_name))  
                {  
                     // push to download the zip  
                     header('Content-type: application/zip');  
                     header('Content-Disposition: attachment; filename="'.$zip_name.'"');  
                     readfile($zip_name);  
                     // remove zip file is exists in temp path  
                     unlink($zip_name);  
                }  
           }  
           else  
           {  
                $error .= "* Please select files to zip ";  
           }  
      }  
      else  
      {  
           $error .= "* You dont have ZIP extension";  
      }  
 }  
 ?> 
<style>.navigation_item{
		padding: 0px 5px;
		background: #fff;
		text-decoration: none;
		
		color: #e3e3e3 !important;
		font-size: 12px;
		border: 2px solid #e3e3e3;
		border-radius: 1px;
		-webkit-transition: all 0.2s linear;
		-moz-transition: all 0.2s linear;
		-ms-transition: all 0.2s linear;
		-o-transition: all 0.2s linear;
	}
	.navigation_item:hover,.selected_navigation_item{
		border: 2px solid #2A6496;
		border-radius: 2px;
		color: #2A6496 !important;
		background: #fff;
	}
	</style>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Download Files</h1>
                </div>
                
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         Download Files Control panel
                        </div>
                        <div class="panel-body">
                        <form name="zips" method="post">  
                     <?php echo $error; ?> 
                           <div class="table-responsive table-bordered">
                          
                           <?php
include"connect.php";
if (isset($_GET["page"])) { $page = $_GET["page"]; } else { $page=1; };
$start_from = ($page-1) * 10;
$sql = "select * from files ORDER BY id DESC LIMIT $start_from, 10";
$rs_result = mysqli_query($con, $sql);
?>
                                <table class="table">
                                    
<thead>
                                        <tr>
                                           <th>*</th>  
                               <th>File Name</th> 
											
											<th>File Type</th> 
                                            <th>Size</th> 
                                            <th>Action</th> 
                                        </tr>
                                    </thead>

<?php
while ($row = mysqli_fetch_assoc($rs_result)) {
?>

<tbody>
                                        <tr>
                                        <td><input type="checkbox" name="files[]" value="<?php echo $row["filename"]; ?>" /></td>
                                                 
                                            <td><?php echo $row["file_id"]; ?></td>
                                                                                        
                                            <td><?php echo $row["type"]; ?></td>
                                             <td><?php echo $row["size"]; ?></td>
                                           
										   <td><a href='deletefile.php?key1=<?php echo $row["id"]; ?>&key2=<?php echo $page ?>'>Delete</a> 
                                        </tr>
										
										</tbody>

<?php
};
?>
<tr>  
                               <td colspan="2"><input type="submit" name="createpdf" class="btn btn-primary"  value="Download as ZIP" />&nbsp;  
                               <input type="reset" name="reset"  class="btn btn-warning" value="Reset" /></td>  
                          </tr>  
</table>
<strong>Pages  </strong>

<?php
$sql = "SELECT COUNT(filename) FROM files";
$rs_result = mysqli_query($con, $sql);
$row = mysqli_fetch_array($rs_result, MYSQLI_BOTH);
$total_records = $row[0];
$total_pages = ceil($total_records / 10);
for ($i=1; $i<=$total_pages; $i++) {
echo "<a href='downloadfiles.php?page=".$i."' class='navigation_item selected_navigation_item'>".$i."</a> ";
};
?>


                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
<!-- jQuery Version 1.11.0 -->
    <script src="js/jquery-1.11.0.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="js/plugins/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="js/plugins/dataTables/dataTables.bootstrap.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });
    </script>
<?php
}
else
{
header("location:login.php");
}
?>
</form>
</body>

</html>
