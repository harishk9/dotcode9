<html>
<body>

<h1>Zip file with a password</h1>

<p>Choose file and set password.</p>

<form method="POST" enctype="multipart/form-data" action="upload.php">
    <input type="file" name="files[]" required multiple />
    <input type="password" name="password" required />
    <input type="submit" name="upload" />
</form>

</body>
</html>
